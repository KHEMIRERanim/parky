#include<stdio.h>
#include <string.h>
#include "projet.h"
#include <glib.h>

int ajouter_avis(char *filename, Avis avis) {
    FILE *f = fopen(filename, "a");
    if (!f) {
        printf("Erreur lors de l'ouverture du fichier.\n");
        return 0;
    }
    fprintf(f, "%d,%s,%s,%d,%s,%d,%d,%d,%d,%d,%s,%s\n",
            avis.cin, avis.nom, avis.prenom, avis.idpark, avis.bloc,
            avis.date.jour, avis.date.mois, avis.date.annee, avis.nbvisit,
            avis.note, avis.textexperience, avis.visit);
    fclose(f);
    return 1;
}

int supprimer_avis(char *filename, int cin) {
    FILE *file = fopen(filename, "r");
    FILE *temp_file = fopen("temp.txt", "w");
    Avis avis;
    int found = 0;

    if (!file || !temp_file) {
        printf("Erreur lors de l'ouverture du fichier.\n");
        return 0;
    }

    // Change fscanf to use comma-separated values
    while (fscanf(file, "%d,%49[^,],%49[^,],%d,%49[^,],%d,%d,%d,%d,%d,%49[^,],%49[^,]",
                  &avis.cin, avis.nom, avis.prenom, &avis.idpark, avis.bloc,
                  &avis.date.jour, &avis.date.mois, &avis.date.annee, &avis.nbvisit,
                  &avis.note, avis.textexperience, avis.visit) != EOF) {
        // If the CIN does not match the one to delete, write the record to the new file
        if (avis.cin != cin) {
            fprintf(temp_file, "%d,%s,%s,%d,%s,%d,%d,%d,%d,%d,%s,%s\n",
                    avis.cin, avis.nom, avis.prenom, avis.idpark, avis.bloc,
                    avis.date.jour, avis.date.mois, avis.date.annee, avis.nbvisit,
                    avis.note, avis.textexperience, avis.visit);
        } else {
            found = 1;  // Record to delete found, do not write to the temporary file
        }
    }

    fclose(file);
    fclose(temp_file);

    // Remove the old file and rename the temporary file to the original filename
    remove(filename);
    rename("temp.txt", filename);

    return found;  // Return whether the avis was found and deleted
}
/*
int afficher_avis(char *filename) {
    	FILE *f = fopen(filename, "r");
    	Avis avis;
	while (fscanf(f,"%d %s %s %d %s %d %d %d %d %d %s %s\n",&avis.cin,avis.nom,avis.prenom,&avis.idpark,avis.bloc,&avis.date.jour,&avis.date.mois,&avis.date.annee,&avis.nbvisit,&avis.note,avis.textexperience,avis.visit) == 10)
	{
		printf("%d %s %s %d %s %d %d %d %d %d %s %s\n",avis.cin, avis.nom, avis.prenom, avis.idpark, avis.bloc, avis.date.jour, avis.date.mois, avis.date.annee, avis.nbvisit, avis.note, avis.textexperience,avis.visit);
    	}

    	fclose(f);
    	return 0;
}*/
int modifier_avis(char *filename, int cin, Avis nouv) {
    FILE *file = fopen(filename, "r");
    FILE *temp_file = fopen("temp.txt", "w");
    char buffer[512];  // Buffer to read each line
    Avis avis;
    int found = 0;

    if (!file || !temp_file) {
        printf("Erreur lors de l'ouverture du fichier.\n");
        if (file) fclose(file);
        if (temp_file) fclose(temp_file);
        return 0;
    }

    while (fgets(buffer, sizeof(buffer), file)) {
        if (sscanf(buffer, "%d,%49[^,],%49[^,],%d,%49[^,],%d,%d,%d,%d,%d,%49[^,],%49[^,]",
                   &avis.cin, avis.nom, avis.prenom, &avis.idpark, avis.bloc,
                   &avis.date.jour, &avis.date.mois, &avis.date.annee,
                   &avis.nbvisit, &avis.note, avis.textexperience, avis.visit) == 12) {
            if (avis.cin == cin) {
                // Write the updated review
                fprintf(temp_file, "%d,%s,%s,%d,%s,%d,%d,%d,%d,%d,%s,%s\n",
                        nouv.cin, nouv.nom, nouv.prenom, nouv.idpark, nouv.bloc,
                        nouv.date.jour, nouv.date.mois, nouv.date.annee,
                        nouv.nbvisit, nouv.note, nouv.textexperience, nouv.visit);
                found = 1;
            } else {
                // Write the original review if no modification
                fputs(buffer, temp_file);
            }
        } else {
            printf("Ligne ignorée (mauvais format) : %s", buffer);
        }
    }

    fclose(file);
    fclose(temp_file);

    // Replace the original file with the temporary one
    remove(filename);
    rename("temp.txt", filename);

    if (found) {
        printf("Avis modifié avec succès.\n");
    } else {
        printf("Aucun avis trouvé avec le CIN : %d\n", cin);
    }

    return found;
}
/*
Avis chercher_avis(char *filename, int cin) {
    Avis avis_cherch;
    int tr=0;
    FILE * f=fopen(filename, "r");
    if(f!=NULL)
    {
        while(tr==0 && fscanf(f,"%d %s %s %d %s %d %d %d %d %d %s %s\n",&avis_cherch.cin,avis_cherch.nom,avis_cherch.prenom,&avis_cherch.idpark,avis_cherch.bloc,&avis_cherch.date.jour,&avis_cherch.date.mois,&avis_cherch.date.annee,&avis_cherch.nbvisit,&avis_cherch.note,avis_cherch.textexperience,avis_cherch.visit)!=EOF)
        {
            if(avis_cherch.cin == cin)
                tr=1;
        }
    }
    fclose(f);
    if(tr==0)
        avis_cherch.cin=-1;
    return avis_cherch;

}*/



void trier_par_note(Avis *avis, int n) {
    int i, j;
    int idParkActuel;
    float totalNotes, moyenne;
    int countAvis;
    for (i = 0; i < n - 1; i++) {
        idParkActuel = avis[i].idpark;
        totalNotes = 0;
        countAvis = 0;
        for (j = i; j < n; j++) {
            if (avis[j].idpark == idParkActuel) {
                totalNotes += avis[j].note;
                countAvis++;
            }
        }
        if (countAvis > 0) {
    		moyenne = totalNotes / countAvis;
	} else {
    		moyenne = 0;
	}
	if (moyenne > avis[i].note) {
            avis[i].note = moyenne;
        }
    }
}
void afficher_avis_in_treeview(GtkTreeView *treeview, Avis *avis, int count) {
    GtkListStore *list_store = GTK_LIST_STORE(gtk_tree_view_get_model(treeview));

    for (int i = 0; i < count; i++) {
        GtkTreeIter iter;
        gtk_list_store_append(list_store, &iter);

        gtk_list_store_set(list_store, &iter, 
                           0, avis[i].cin,
                           1, avis[i].nom,
                           2, avis[i].prenom,
                           3, avis[i].idpark,
                           4, avis[i].bloc,
                           5, avis[i].date.jour,
                           6, avis[i].date.mois,
                           7, avis[i].date.annee,
			   8, avis[i].nbvisit,
			   9, avis[i].textexperience,
                           -1);
    }
}
int afficherpark_trie(char *filename) {
    FILE *file = fopen(filename, "r");
    int n = 0;
    Avis avisList[100]; 
    while (fscanf(file, "%d %s %s %d %s %d %d %d %d %s %s\n",&avisList[n].cin,avisList[n].nom, avisList[n].prenom,&avisList[n].idpark,avisList[n].bloc, &avisList[n].date.jour,&avisList[n].date.mois,&avisList[n].date.annee,&avisList[n].note, avisList[n].textexperience,avisList[n].visit) == 9) {
        n++;
        if (n >=100) {
            break;
        }
    }
    fclose(file);
    trier_par_note(avisList, n);
    printf("Parkings triés par note (décroissant) :\n");
    for (int i = 0; i < n; i++) {
        printf("Parking ID: %d, Moyenne des notes: %.2d\n", avisList[i].idpark, avisList[i].note);
    }

    return 0;
}
int charger_avis(Avis *avis, int max_count) {
    FILE *file = fopen("avis.txt", "r");
    int count = 0;

    if (file) {
        while (fscanf(file, "%d,%49[^,],%49[^,],%d,%49[^,],%d,%d,%d,%d,%d,%49[^,],%49[^,]",
       &avis[count].cin, avis[count].nom, avis[count].prenom, &avis[count].idpark, avis[count].bloc,
       &avis[count].date.jour, &avis[count].date.mois, &avis[count].date.annee, &avis[count].nbvisit,
       &avis[count].note, avis[count].textexperience, avis[count].visit) != EOF) {

            count++;
            if (count >= max_count) break;
        }
        fclose(file);
    } else {
        printf("Erreur lors de l'ouverture du fichier reservation.txt\n");
    }

    return count;
}

