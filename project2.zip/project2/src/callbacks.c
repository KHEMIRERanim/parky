#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "projet.h"
#include "projet.c" 
void on_button_soumettrealine_clicked(GtkWidget *objet_graphique, gpointer user_data)
{
    GtkWidget *button_soumettrealine;
    button_soumettrealine = lookup_widget(objet_graphique, "button_soumettrealine");

    // Ensure all widgets are looked up correctly and valid
    GtkWidget *input_expbon = lookup_widget(objet_graphique, "radiobutton_bon");
	GtkWidget *input_expmauv = lookup_widget(objet_graphique, "radiobutton_mauv");
    GtkWidget *input_cin = lookup_widget(objet_graphique, "entry_cinam");
    GtkWidget *input_prenom = lookup_widget(objet_graphique, "entry_prenomam");
    GtkWidget *input_nom = lookup_widget(objet_graphique, "entry_nomam");
    GtkWidget *input_idpark = lookup_widget(objet_graphique, "entry_idparkam");
    GtkWidget *input_checkavisiter = lookup_widget(objet_graphique, "checkbutton_avisiteraline");
    GtkWidget *input_checkanepasvisiter = lookup_widget(objet_graphique, "checkbutton_anepasvisiteraline");
    GtkWidget *input_spinj = lookup_widget(objet_graphique, "spinbutton_jouraline");
    GtkWidget *input_spinm = lookup_widget(objet_graphique, "spinbutton_moisaline");
    GtkWidget *input_spina = lookup_widget(objet_graphique, "spinbutton_anneealine");
    GtkWidget *input_combobloc = lookup_widget(objet_graphique, "combobox_bloc");
    GtkWidget *input_spinnote = lookup_widget(objet_graphique, "spinbutton_note");
    GtkWidget *input_spinnbvisit = lookup_widget(objet_graphique, "spinbutton_nbvisit");
    GtkWidget *label_messageajout = lookup_widget(objet_graphique, "label_messageam");

    // Check if essential widgets are NULL
    if (!input_cin || !input_prenom || !input_nom || !input_idpark || !input_expbon || !input_expmauv || !input_checkavisiter || !input_checkanepasvisiter || !input_spinj || !input_spinm || !input_spina || !input_combobloc || !input_spinnote || !input_spinnbvisit) {
        g_print("Error: One or more required widgets not found!\n");
        return; // Exit if any widget is missing
    }

    Avis avis;
    Date date;

    // Safely retrieve values and ensure proper memory bounds for strings
    avis.cin = atoi(gtk_entry_get_text(GTK_ENTRY(input_cin)));

    strncpy(avis.prenom, gtk_entry_get_text(GTK_ENTRY(input_prenom)), sizeof(avis.prenom) - 1);
    avis.prenom[sizeof(avis.prenom) - 1] = '\0';  // Ensure null termination

    strncpy(avis.nom, gtk_entry_get_text(GTK_ENTRY(input_nom)), sizeof(avis.nom) - 1);
    avis.nom[sizeof(avis.nom) - 1] = '\0';

    avis.idpark = atoi(gtk_entry_get_text(GTK_ENTRY(input_idpark)));

    // Handle checkboxes for "A visiter" and "A ne pas visiter"
    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(input_checkavisiter))) {
        strncpy(avis.visit, "A visiter", sizeof(avis.visit) - 1);
    } else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(input_checkanepasvisiter))) {
        strncpy(avis.visit, "A ne pas visiter", sizeof(avis.visit) - 1);
    }
	if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(input_expbon))) {
    	strncpy(avis.textexperience, "bonne", sizeof(avis.textexperience) - 1);
	} else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(input_expmauv))) {
    	strncpy(avis.textexperience, "pire", sizeof(avis.textexperience) - 1);
	}
    // Retrieve spin button values
    avis.date.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input_spinj));
    avis.date.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input_spinm));
    avis.date.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input_spina));
    avis.note = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input_spinnote));
    avis.nbvisit = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input_spinnbvisit));

	    const char *bloc = gtk_combo_box_get_active_text(GTK_COMBO_BOX(input_combobloc));

    if (bloc != NULL) {
        // Copiez la chaîne dans le champ bloc de l'avis
        strncpy(avis.bloc, bloc, sizeof(avis.bloc) - 1);
        avis.bloc[sizeof(avis.bloc) - 1] = '\0';
        g_print("Bloc sélectionné : %s\n", avis.bloc);  // Affiche la chaîne du bloc
    }
	
    // Add the Avis entry
    if (ajouter_avis("avis.txt", avis )) {
        // If the addition was successful, display success message
        gtk_label_set_text(GTK_LABEL(label_messageajout), "Ajout avec succès !");
    } else {
        // If there was an error, display an error message
        gtk_label_set_text(GTK_LABEL(label_messageajout), "Erreur lors de l'ajout d'avis.");
    }
}

void
on_button_quitaline_clicked(GtkWidget *objet_graphique, gpointer user_data)
{
    GtkWidget *ajoutavis_window = gtk_widget_get_toplevel(objet_graphique);
    if (GTK_IS_WINDOW(ajoutavis_window)) {
        gtk_widget_destroy(ajoutavis_window); 
    }
}


void
on_am_main_ajout_button_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *ajoutavis_window;
	ajoutavis_window = create_ajoutavis_window();
	gtk_widget_show(ajoutavis_window);

}


void
on_am_main_modif_button_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *modifavis_window;
	modifavis_window = create_modifavis_window();
	gtk_widget_show(modifavis_window);
}


void on_am_main_supprimer_button_clicked(GtkButton *button, gpointer user_data) {
    GtkWidget *suppression_avis_window;
    GtkWidget *treeview_avis;
    GtkListStore *store;
    GtkTreeIter iter;

    // Créer la fenêtre depuis le fichier Glade
    suppression_avis_window = create_suppression_avis_window();
    gtk_widget_show(suppression_avis_window);

    // Récupérer le TreeView depuis la fenêtre
    treeview_avis = lookup_widget(suppression_avis_window, "treeview_avis");

    // Créer un GtkListStore avec les 10 colonnes en G_TYPE_STRING
    store = gtk_list_store_new(10, 
                               G_TYPE_STRING,  // CIN
                               G_TYPE_STRING,  // Nom
                               G_TYPE_STRING,  // Prénom
                               G_TYPE_STRING,  // ID Parking
                               G_TYPE_STRING,  // Bloc
                               G_TYPE_STRING,  // Jour
                               G_TYPE_STRING,  // Mois
                               G_TYPE_STRING,  // Année
                               G_TYPE_STRING,  // Note
                               G_TYPE_STRING   // Nombre de visites
    );

    // Charger les avis depuis le fichier
    Avis avisList[100];  // Tableau pour stocker jusqu'à 100 avis
    int count = charger_avis(avisList, 100);  // Fonction pour charger les données d'avis

    // Si aucun avis n'est trouvé, s'assurer que le TreeView est vide
    if (count == 0) {
        gtk_label_set_text(GTK_LABEL(lookup_widget(suppression_avis_window, "label_ressupp")), "Aucun avis trouvé.");
    }

    // Ajouter les avis au GtkListStore
    for (int i = 0; i < count; i++) {
        gtk_list_store_append(store, &iter);

        // Conversion des entiers en chaînes de caractères
        char cin_str[10], idpark_str[10], jour_str[10], mois_str[10], annee_str[10], note_str[10], nbvisit_str[10];
        snprintf(cin_str, sizeof(cin_str), "%d", avisList[i].cin);
        snprintf(idpark_str, sizeof(idpark_str), "%d", avisList[i].idpark);
        snprintf(jour_str, sizeof(jour_str), "%d", avisList[i].date.jour);
        snprintf(mois_str, sizeof(mois_str), "%d", avisList[i].date.mois);
        snprintf(annee_str, sizeof(annee_str), "%d", avisList[i].date.annee);
        snprintf(note_str, sizeof(note_str), "%d", avisList[i].note);
        snprintf(nbvisit_str, sizeof(nbvisit_str), "%d", avisList[i].nbvisit);

        // Ajouter les données converties au store
        gtk_list_store_set(store, &iter,
                           0, cin_str,                  // CIN
                           1, avisList[i].nom,          // Nom
                           2, avisList[i].prenom,       // Prénom
                           3, idpark_str,               // ID Parking
                           4, avisList[i].bloc,         // Bloc
                           5, jour_str,                 // Jour
                           6, mois_str,                 // Mois
                           7, annee_str,                // Année
                           8, note_str,                 // Note
                           9, nbvisit_str,              // Nombre de visites
                           -1);                         // Fin des données de ligne
    }

    // Ajouter les colonnes au TreeView
    GtkCellRenderer *renderer = gtk_cell_renderer_text_new();
    GtkTreeViewColumn *column;

    // Définir les colonnes
    column = gtk_tree_view_column_new_with_attributes("CIN", renderer, "text", 0, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_avis), column);

    column = gtk_tree_view_column_new_with_attributes("Nom", renderer, "text", 1, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_avis), column);

    column = gtk_tree_view_column_new_with_attributes("Prénom", renderer, "text", 2, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_avis), column);

    column = gtk_tree_view_column_new_with_attributes("ID Parking", renderer, "text", 3, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_avis), column);

    column = gtk_tree_view_column_new_with_attributes("Bloc", renderer, "text", 4, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_avis), column);

    column = gtk_tree_view_column_new_with_attributes("Jour", renderer, "text", 5, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_avis), column);

    column = gtk_tree_view_column_new_with_attributes("Mois", renderer, "text", 6, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_avis), column);

    column = gtk_tree_view_column_new_with_attributes("Année", renderer, "text", 7, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_avis), column);

    column = gtk_tree_view_column_new_with_attributes("Note", renderer, "text", 8, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_avis), column);

    column = gtk_tree_view_column_new_with_attributes("Nombre de visites", renderer, "text", 9, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_avis), column);

    // Associer le modèle au TreeView
    gtk_tree_view_set_model(GTK_TREE_VIEW(treeview_avis), GTK_TREE_MODEL(store));
    g_object_unref(store);  // Libérer la mémoire allouée
}


void
on_am_main_affichpark_button_clicked   (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *affich_park_window;
	affich_park_window = create_affich_park_window();
	gtk_widget_show(affich_park_window);
}

void on_button_modifam_clicked(GtkWidget *button, gpointer user_data) {
    // Récupérer le CIN de l'avis à modifier
    GtkWidget *entry_cin = lookup_widget(GTK_WIDGET(button), "entry_recherchcin");
    const char *cin_recherche = gtk_entry_get_text(GTK_ENTRY(entry_cin));

    if (strlen(cin_recherche) == 0) {
        GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(gtk_widget_get_toplevel(GTK_WIDGET(button))),
                                                   GTK_DIALOG_MODAL,
                                                   GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_OK,
                                                   "Veuillez entrer un CIN valide.");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return;
    }
	
    // Convertir le CIN en entier
    int cin_cherch = atoi(cin_recherche);
    g_print("CIN : %d\n", cin_cherch);  // Débogage : Affichage du CIN récupéré

    // Déclaration des widgets
    GtkWidget *input_nomnouv, *input_prenomnouv, *input_idparknouv, *input_checkavisiternouv, *input_checkanepasvisiternouv;
    GtkWidget *input_spinjnouv, *input_spinmnouv, *input_spinanouv, *input_spinnotenouv, *input_spinnbvisitnouv;
    GtkWidget *input_comboblocnouv, *input_expmieu, *input_exppire;
    Avis nouv;
    // Récupération des widgets
    input_nomnouv = lookup_widget(button, "entry_nomnouv");
    input_prenomnouv = lookup_widget(button, "entry_prenomnouv");
    input_idparknouv = lookup_widget(button, "entry_idparknouv");
    input_checkavisiternouv = lookup_widget(button, "checkbutton_avisiternouv");
    input_checkanepasvisiternouv = lookup_widget(button, "checkbutton_anepasvisiternouv");
    input_spinjnouv = lookup_widget(button, "spinbutton_jnouv");
    input_spinmnouv = lookup_widget(button, "spinbutton_mnouv");
    input_spinanouv = lookup_widget(button, "spinbutton_anouv");
    input_spinnotenouv = lookup_widget(button, "spinbutton_notenouv");
    input_spinnbvisitnouv = lookup_widget(button, "spinbutton_nbvisitnouv");
    input_comboblocnouv = lookup_widget(button, "combobox_blocnouv");
    input_expmieu = lookup_widget(button, "radiobutton_expmieu");
    input_exppire = lookup_widget(button, "radiobutton_exppire");

    // Récupérer les données des widgets pour remplir la structure Avis
    nouv.cin = atoi(gtk_entry_get_text(GTK_ENTRY(entry_cin)));
    g_print("CIN : %d\n", nouv.cin);  // Débogage : Affichage du CIN

    // Nom et prénom
    strncpy(nouv.nom, gtk_entry_get_text(GTK_ENTRY(input_nomnouv)), sizeof(nouv.nom) - 1);
    nouv.nom[sizeof(nouv.nom) - 1] = '\0';
    g_print("Nom : %s\n", nouv.nom);

    strncpy(nouv.prenom, gtk_entry_get_text(GTK_ENTRY(input_prenomnouv)), sizeof(nouv.prenom) - 1);
    nouv.prenom[sizeof(nouv.prenom) - 1] = '\0';
    g_print("Prénom : %s\n", nouv.prenom);

    // ID Parking
    nouv.idpark = atoi(gtk_entry_get_text(GTK_ENTRY(input_idparknouv)));
    g_print("ID Parking : %d\n", nouv.idpark);

    // Expérience
    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(input_expmieu))) {
        strncpy(nouv.textexperience, "améliorée", sizeof(nouv.textexperience) - 1);
        nouv.textexperience[sizeof(nouv.textexperience) - 1] = '\0';
        g_print("Expérience : %s\n", nouv.textexperience);
    } else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(input_exppire))) {
        strncpy(nouv.textexperience, "pire", sizeof(nouv.textexperience) - 1);
        nouv.textexperience[sizeof(nouv.textexperience) - 1] = '\0';
        g_print("Expérience : %s\n", nouv.textexperience);
    }

    // Choix de visite
    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(input_checkavisiternouv))) {
        strncpy(nouv.visit, "A visiter", sizeof(nouv.visit) - 1);
        nouv.visit[sizeof(nouv.visit) - 1] = '\0';
        g_print("Choix : %s\n", nouv.visit);
    } else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(input_checkanepasvisiternouv))) {
        strncpy(nouv.visit, "A ne pas visiter", sizeof(nouv.visit) - 1);
        nouv.visit[sizeof(nouv.visit) - 1] = '\0';
        g_print("Choix : %s\n", nouv.visit);
    }

    // Récupérer les dates
    nouv.date.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input_spinjnouv));
    nouv.date.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input_spinmnouv));
    nouv.date.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input_spinanouv));
    g_print("Date : %02d/%02d/%d\n", nouv.date.jour, nouv.date.mois, nouv.date.annee);

    // Note et nombre de visites
    nouv.note = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input_spinnotenouv));
    g_print("Note : %d\n", nouv.note);

    nouv.nbvisit = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input_spinnbvisitnouv));
    g_print("Nombre de visites : %d\n", nouv.nbvisit);

    // Bloc
    const char *blocnouv = gtk_combo_box_get_active_text(GTK_COMBO_BOX(input_comboblocnouv));
    if (blocnouv != NULL) {
        strncpy(nouv.bloc, blocnouv, sizeof(nouv.bloc) - 1);
        nouv.bloc[sizeof(nouv.bloc) - 1] = '\0';
        g_print("Bloc : %s\n", nouv.bloc);
    }

    // Appeler la fonction de modification de l'avis
    if (modifier_avis("avis.txt", cin_cherch, nouv)) {
        GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(gtk_widget_get_toplevel(GTK_WIDGET(button))),
                                                   GTK_DIALOG_MODAL,
                                                   GTK_MESSAGE_INFO,
                                                   GTK_BUTTONS_OK,
                                                   "Modification réussie !");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
    } else {
        GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(gtk_widget_get_toplevel(GTK_WIDGET(button))),
                                                   GTK_DIALOG_MODAL,
                                                   GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_OK,
                                                   "Erreur lors de la modification.");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
    }
}
void on_button_cherchavis_clicked(GtkButton *button, gpointer user_data) {
    GtkWidget *entry_recherchercin;
    GtkWidget *label_msgcherch;
    const char *cin_text;
    char buffer[256];
    int found = 0;

    // Récupération des widgets
    entry_recherchercin = lookup_widget(GTK_WIDGET(button), "entry_recherchcin");
    label_msgcherch = lookup_widget(GTK_WIDGET(button), "label_messagecherch");

    if (entry_recherchercin && label_msgcherch) {
        cin_text = gtk_entry_get_text(GTK_ENTRY(entry_recherchercin));
	if (cin_text && strlen(cin_text) > 0) {
            int cin_cherch = atoi(cin_text);
            FILE *file = fopen("avis.txt", "r");
            if (file) {
                while (fgets(buffer, sizeof(buffer), file)) {
                     int cin; // Change the id variable to an integer
                     sscanf(buffer, "%d", &cin); // Lire l'ID comme un entier
                     if (cin == cin_cherch) { // Compare integer values
                         found = 1;
                         break;
                    }
                }
                fclose(file);
            } else {
                // Afficher un message d'erreur si le fichier ne peut pas être ouvert
                gtk_label_set_text(GTK_LABEL(label_msgcherch), "Erreur: Impossible d'ouvrir le fichier.");
                printf("Erreur: Impossible d'ouvrir le fichier avis.txt\n");
                return;
            }

            // Si l'avis est trouvé
            if (found) {
                gtk_label_set_text(GTK_LABEL(label_msgcherch), "CIN trouvé : Veuillez modifier l'avis.");
                printf("CIN trouvé : Veuillez modifier l'avis.\n");

                // Connexion du signal si le CIN est trouvé
                if (!g_signal_handlers_block_matched(button, G_SIGNAL_MATCH_FUNC, 0, 0, NULL, G_CALLBACK(on_button_modifam_clicked), NULL)) {
                    gpointer user_data_cin = g_strdup(cin_text);  // Allouer une copie du CIN
                    g_signal_connect(button, "clicked", G_CALLBACK(on_button_modifam_clicked), user_data_cin);
                }
            } else {
                // Si le CIN n'est pas trouvé
                gtk_label_set_text(GTK_LABEL(label_msgcherch), "CIN non trouvé.");
                printf("CIN non trouvé.\n");
            }
        } else {
            // Afficher un message d'erreur si le CIN est vide
            gtk_label_set_text(GTK_LABEL(label_msgcherch), "Veuillez entrer un CIN valide.");
            printf("Veuillez entrer un CIN valide.\n");
        }
    } else {
        // Si les widgets ne peuvent pas être récupérés
        gtk_label_set_text(GTK_LABEL(label_msgcherch), "Erreur: Impossible de récupérer les widgets.");
        printf("Erreur: Impossible de récupérer les widgets.\n");
    }
}


void
on_button_quitsupp_clicked(GtkWidget *objet_graphique, gpointer user_data)
{
    GtkWidget *suppression_avis = gtk_widget_get_toplevel(objet_graphique);
    if (GTK_IS_WINDOW(suppression_avis)) {
        gtk_widget_destroy(suppression_avis); 
    }
}
void on_button_confsuppam_clicked(GtkButton *button, gpointer user_data) {

    GtkWidget *suppression_avis_window = gtk_widget_get_toplevel(GTK_WIDGET(button));
    GtkWidget *treeview_avis = lookup_widget(suppression_avis_window, "treeview_avis");

    if (!treeview_avis) {
        g_print("Erreur: TreeView non trouvé.\n");
        return;
    }

    GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview_avis));
    GtkTreeModel *model;
    GtkTreeIter iter;

    if (gtk_tree_selection_get_selected(selection, &model, &iter)) {
        char *cin_str;
        gtk_tree_model_get(model, &iter, 0, &cin_str, -1);  // Get the CIN (assumed to be in the first column)
        g_print("Avis sélectionné avec CIN: %s\n", cin_str);

        int cin = atoi(cin_str);  // Convert CIN to integer

        // Call the function to delete the review
        int result = supprimer_avis("avis.txt", cin);

        if (result) {
            g_print("L'Avis avec CIN %d a été supprimé avec succès.\n", cin);

            // Remove the item from the treeview list store
            gtk_list_store_remove(GTK_LIST_STORE(model), &iter);
        } else {
            g_print("Erreur: Avis avec CIN %d non trouvé.\n", cin);

            // Show an error message dialog
            GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(suppression_avis_window),
                                                      GTK_DIALOG_MODAL,
                                                      GTK_MESSAGE_ERROR,
                                                      GTK_BUTTONS_OK,
                                                      "L'avis avec le CIN sélectionné n'a pas été trouvé.");
            gtk_dialog_run(GTK_DIALOG(dialog));
            gtk_widget_destroy(dialog);
        }

        g_free(cin_str);
    } else {
        // If no selection is made, show a dialog prompting to select an item
        GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(suppression_avis_window),
                                                  GTK_DIALOG_MODAL,
                                                  GTK_MESSAGE_ERROR,
                                                  GTK_BUTTONS_OK,
                                                  "Veuillez sélectionner un avis à supprimer.");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
    }
}


void
on_button_quitmodif_clicked(GtkWidget *objet_graphique, gpointer user_data)
{
	GtkWidget *modifavis_window = gtk_widget_get_toplevel(objet_graphique);
    	if (GTK_IS_WINDOW(modifavis_window)) {
        	gtk_widget_destroy(modifavis_window); 
    	}
}


void
on_button_quitshowpark_clicked(GtkWidget *objet_graphique, gpointer user_data)
{
	GtkWidget *affich_park_window = gtk_widget_get_toplevel(objet_graphique);
    	if (GTK_IS_WINDOW(affich_park_window)) {
        	gtk_widget_destroy(affich_park_window); 
    	}
}
void load_combo_box_from_file(GtkWidget *combobox, const char *filename) {
    // Remove all items from the ComboBox (GTK+ 2.x)
    gint item_count = gtk_combo_box_get_active(GTK_COMBO_BOX(combobox));
    while (item_count >= 0) {
        gtk_combo_box_remove_text(GTK_COMBO_BOX(combobox), item_count);
        item_count--;
    }

    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        g_print("Erreur: Impossible d'ouvrir le fichier %s\n", filename);
        return;
    }

    char line[1024];  // Increased size to handle longer lines
    while (fgets(line, sizeof(line), file)) {
        // Remove any trailing newline characters from the line
        line[strcspn(line, "\n")] = 0;

        // Strip any leading/trailing spaces from the line (optional)
        g_strstrip(line);

        // Add the entire line into the ComboBox
        gtk_combo_box_append_text(GTK_COMBO_BOX(combobox), line);
    }

    fclose(file);
}






void
on_button_charg_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *comboboxentry_avis = lookup_widget(GTK_WIDGET(button), "comboboxentry_avis");
    load_combo_box_from_file(comboboxentry_avis, "avis.txt");
}


void
on_button_affich_parking_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}

