#include <gtk/gtk.h>

void
on_button_soumettrealine_clicked(GtkWidget *objet_graphique, gpointer user_data);

void
on_button_quitaline_clicked(GtkWidget *objet_graphique, gpointer user_data);

void
on_am_main_ajout_button_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_am_main_modif_button_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_am_main_supprimer_button_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_am_main_affichavis_button_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_am_main_affichpark_button_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void on_button_modifam_clicked(GtkWidget *objet_graphique, gpointer user_data);

void
on_button_cherchavis_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_quitsupp_clicked(GtkWidget *objet_graphique, gpointer user_data);

void
on_button_confsuppam_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_quitmodif_clicked(GtkWidget *objet_graphique, gpointer user_data);

void
on_button_quitshowpark_clicked(GtkWidget *objet_graphique, gpointer user_data);


void
on_button_charg_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_affich_parking_clicked       (GtkButton       *button,
                                        gpointer         user_data);
