#ifndef PROJET_H_INCLUDED
#define PROJET_H_INCLUDED
#include <stdio.h>
#include <gtk/gtk.h>

typedef struct{
	int jour;
	int mois;
	int annee; 
}Date; 
typedef struct {
	int cin;
	char nom[50];
	char prenom[50];
	int idpark;
	char bloc[50];
	Date date;
	int nbvisit;
	int note;
	char textexperience[200];
	char visit[10];
}Avis;
 
int ajouter_avis (char * filename, Avis avis ); 
int modifier_avis(char * filename, int cin, Avis nouv);
int supprimer_avis(char * filename, int cin);
//int afficher_avis(char *filename);
//Avis chercher_avis(char *filename, int cin);
void trier_par_note(Avis *avis, int n);
void afficher_avis_in_treeview(GtkTreeView *treeview, Avis *avis, int count);
int afficherpark_trie(char *filename);
int charger_avis(Avis *avis, int max_count);
#endif

